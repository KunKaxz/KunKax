package com.fsck.k9.mail;

public enum ConnectionSecurity {
    NONE,
    STARTTLS_REQUIRED,
    SSL_TLS_REQUIRED
}
